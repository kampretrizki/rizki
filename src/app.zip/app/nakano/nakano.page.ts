import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nakano',
  templateUrl: './nakano.page.html',
  styleUrls: ['./nakano.page.scss'],
})
export class NakanoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
