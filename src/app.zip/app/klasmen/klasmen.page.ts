import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-klasmen',
  templateUrl: './klasmen.page.html',
  styleUrls: ['./klasmen.page.scss'],
})
export class KlasmenPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
