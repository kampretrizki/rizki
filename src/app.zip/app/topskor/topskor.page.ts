import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topskor',
  templateUrl: './topskor.page.html',
  styleUrls: ['./topskor.page.scss'],
})
export class TopskorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
