import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yosino',
  templateUrl: './yosino.page.html',
  styleUrls: ['./yosino.page.scss'],
})
export class YosinoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
