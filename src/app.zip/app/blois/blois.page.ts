import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blois',
  templateUrl: './blois.page.html',
  styleUrls: ['./blois.page.scss'],
})
export class BloisPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
