import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tina',
  templateUrl: './tina.page.html',
  styleUrls: ['./tina.page.scss'],
})
export class TinaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
