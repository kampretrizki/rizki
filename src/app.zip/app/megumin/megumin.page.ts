import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-megumin',
  templateUrl: './megumin.page.html',
  styleUrls: ['./megumin.page.scss'],
})
export class MeguminPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
