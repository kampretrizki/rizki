import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kotori',
  templateUrl: './kotori.page.html',
  styleUrls: ['./kotori.page.scss'],
})
export class KotoriPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
