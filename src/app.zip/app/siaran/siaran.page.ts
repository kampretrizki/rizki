import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-siaran',
  templateUrl: './siaran.page.html',
  styleUrls: ['./siaran.page.scss'],
})
export class SiaranPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
