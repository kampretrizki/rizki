import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jadwal',
  templateUrl: './jadwal.page.html',
  styleUrls: ['./jadwal.page.scss'],
})
export class JadwalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
